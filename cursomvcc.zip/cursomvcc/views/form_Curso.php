<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inserir curso</title>
</head>
<body>
    <h1>Curso</h1>
    <form action="#" method="post"> 
        <label for="nome">Curso</label>
        <input type="text" name="nome" id="nome">
        <div><?php echo $msg;?></div>
        <br><br>
        <input type="submit" value="Cadastrar">
</body>
</html>